package pl.edu.pjatk.pjatkwej.Models;

public enum SandwichSize {
    SMALL, MEDIUM, BIG, KING_SIZE
}
