package pl.edu.pjatk.pjatkwej;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PjatkwejApplicationTests {

	@Test
	void contextLoads() {
	}

}
